﻿using ShopContent.Context;
using ShopContent.ViewModell;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using ShopContent.Classes;

namespace ShopContent.View
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : Page
    {
		public ItemsContext AllItems = new ItemsContext();
		public Main()
        {
            InitializeComponent();
			foreach (Modell.Items Product in AllItems.Items)
				Parent.Children.Add(new Items.Item(Product, this));
		}
		private void AddItem(object sender, RoutedEventArgs e)
		{
			MainWindow.init.OpenIndex(new View.Add(this));
		}
	}
}
