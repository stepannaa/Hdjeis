﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ShopContent.Classes;
using ShopContent.Context;

namespace ShopContent.View.Items
{
    /// <summary>
    /// Логика взаимодействия для Item.xaml
    /// </summary>
    public partial class Item : UserControl
    {
        public CategorysContext AllCategory = new CategorysContext();
		Main Main;
		Modell.Items Product;
		public Item(Modell.Items Product, Main Main)
        {
            InitializeComponent();
			this.Name.Text = Product.Name;
			this.Description.Text = Product.Description;
			this.Price.Text = Product.Price.ToString();
			this.IdCategory.Text = AllCategory.Categorys.Where(x => x.Id == Product.IdCategory).First().Name;
			this.Main = Main;
			this.Product = Product;
		}
		private void EditItem(object sender, RoutedEventArgs e)
		{
			MainWindow.init.OpenIndex(new View.Add(this.Main, this.Product));
		}
		private void DeleteItem(object sender, RoutedEventArgs e)
		{
			Main.AllItems.Items.Remove(Product);
			Main.AllItems.SaveChanges();
			Main.Parent.Children.Remove(this);
		}
	}
}
