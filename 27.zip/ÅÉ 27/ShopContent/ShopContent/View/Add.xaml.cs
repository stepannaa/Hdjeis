﻿using ShopContent.Context;
using ShopContent.Modell;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ShopContent.View
{
    /// <summary>
    /// Логика взаимодействия для Add.xaml
    /// </summary>
    public partial class Add : Page
    {
        public CategorysContext AllCategory = new CategorysContext();
        public Modell.Items Product;
		public Main Main;
		public Add(Main Main, Modell.Items Product = null)
        {
            InitializeComponent();
			this.Main = Main;
			foreach (Modell.Categorys Category in AllCategory.Categorys)
				cbCategory.Items.Add(Category.Name);
			cbCategory.Items.Add("Выберите...");
			if (Product != null)
			{
				this.Product = Product;
				this.Name.Text = Product.Name;
				this.Description.Text = Product.Description;
				this.Price.Text = Product.Price.ToString();  
				cbCategory.SelectedItem = AllCategory.Categorys.Where(x => x.Id == Product.IdCategory).First().Name;
				BtnAdd.Content = "Изменить";
			}
		}
		private void AddProduct(object sender, RoutedEventArgs e)
		{
			if (this.Product == null)
			{
				Product = new Modell.Items();
				Product.Name = this.Name.Text;
				Product.Description = this.Description.Text;
				Product.Price = Convert.ToInt32(this.Price.Text);
				Product.IdCategory = AllCategory.Categorys.Where(x => x.Name == cbCategory.SelectedItem).First().Id;
				this.Main.AllItems.Items.Add(this.Product);
			}
			else
			{
				Product.Name = this.Name.Text;
				Product.Description = this.Description.Text;
				Product.Price = Convert.ToInt32(this.Price.Text);
				Product.IdCategory = AllCategory.Categorys.Where(x => x.Name == cbCategory.SelectedItem).First().Id;
			}
			this.Main.AllItems.SaveChanges();
			MainWindow.init.OpenIndex(new View.Main());
		}
	}
}
