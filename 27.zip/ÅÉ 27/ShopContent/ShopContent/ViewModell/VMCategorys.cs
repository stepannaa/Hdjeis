﻿using ShopContent.Modell;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ShopContent.ViewModell
{
    //public class VMCategorys : INotifyPropertyChanged
    //{
    //    public List<Context.CategorysContext> Categorys { get; set; }
    //    public VMCategorys() =>
    //        Categorys = Context.CategorysContext.AllCategorys();
    //    public event PropertyChangedEventHandler PropertyChanged;
    //    public void OnPropertyChanged([CallerMemberName] string prop = "")
    //    {
    //        if (PropertyChanged != null)
    //            PropertyChanged(this, new PropertyChangedEventArgs(prop));
    //    }
    //}
}
