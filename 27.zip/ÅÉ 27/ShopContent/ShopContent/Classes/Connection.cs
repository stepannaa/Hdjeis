﻿using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace ShopContent.Classes
{
    public class Connection
    {
		//private static readonly string config = "server=student.permaviat.ru;" +
		//    "Trusted_Connection=No;" +
		//    "DataBase=ShopContent;" +
		//    "User=***;" +
		//    "PWD=***;";
		private static readonly string config = "server=localhost;port=3306;uid=root;pwd=;database=ShopContent;";
		//public static SqlConnection OpenConnection()
		//      {
		//          SqlConnection connection = new SqlConnection(config);
		//          connection.Open();
		//          return connection;
		//      }
		public static MySqlConnection OpenConnection()
		{
			MySqlConnection connection = new MySqlConnection(config);
			connection.Open();
			return connection;
		}
		//public static SqlDataReader Query(string SQL, out SqlConnection connection)
		//      {
		//          connection= OpenConnection();
		//          return new SqlCommand(SQL, connection).ExecuteReader();
		//      }
		public static MySqlDataReader Query(string SQL, MySqlConnection connection)
		{
			return new MySqlCommand(SQL, connection).ExecuteReader();
		}
		//public static void CloseConnection(SqlConnection connection)
		//      {
		//          connection.Close();
		//          SqlConnection.ClearPool(connection);
		//      }
		public static void CloseConnection(MySqlConnection connection)
		{
			connection.Close();
			MySqlConnection.ClearPool(connection);
		}
	}
}
