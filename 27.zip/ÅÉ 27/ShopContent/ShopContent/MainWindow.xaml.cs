﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ShopContent
{
    public partial class MainWindow : Window
    {
        public static MainWindow init;
        public MainWindow()
        {
            InitializeComponent();
            init= this;
            OpenIndex(new View.Main());

		}
        public void OpenIndex(Page Page) =>
            frame.Navigate(Page);

		private void OpenIndex(object sender, MouseButtonEventArgs e)
		{

        }
    }
}
