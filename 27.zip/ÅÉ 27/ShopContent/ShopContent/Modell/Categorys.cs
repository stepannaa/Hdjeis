﻿using System.Runtime.CompilerServices;
using System.ComponentModel;

namespace ShopContent.Modell
{
    public class Categorys
    {
		public int Id { get; set; }
		public string Name { get; set; }
	}
}
