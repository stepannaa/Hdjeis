﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ShopContent.Modell;

namespace ShopContent.Context
{
    public class ItemsContext : DbContext
	{
		public DbSet<Items> Items { get; set; }
		public ItemsContext() =>
			Database.EnsureCreated();
		static string ConnectionConfig = "server=localhost;port=3306;uid=root;pwd=;database=ShopContent;";
		static MySqlServerVersion Version = new MySqlServerVersion(new Version(8, 0, 11));
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) =>
			optionsBuilder.UseMySql(ConnectionConfig, Version);
	}
}
