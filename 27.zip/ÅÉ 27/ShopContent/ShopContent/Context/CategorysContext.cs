﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ShopContent.Modell;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace ShopContent.Context
{
    public class CategorysContext : DbContext
	{
		public DbSet<Categorys> Categorys { get; set; }
		public CategorysContext() =>
			Database.EnsureCreated();
		static string ConnectionConfig = "server=127.0.0.1;port=3306;uid=root;pwd=;database=ShopContent;";
		static MySqlServerVersion Version = new MySqlServerVersion(new Version(8, 0, 11));
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) =>
			optionsBuilder.UseMySql(ConnectionConfig, Version);
	}
}
